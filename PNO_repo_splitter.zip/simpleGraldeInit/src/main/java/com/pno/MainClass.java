package com.pno;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.Properties;

public class MainClass {

    private static Logger logger = LogManager.getLogger();

    public static void main(String[] args) {


        Properties props = new Properties();
        try {
            props.load( MainClass.class.getResourceAsStream("../../simple.properties"));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        System.out.println("Hello Vano!!!" + props.get("vano.surname"));

        Properties sysProps = System.getProperties();
//        System.out.println(sysProps.);
        sysProps.list(System.out);

        logger.error(" This is logger message!!!!!!! ");
        logger.info(" This is logger DEBUG message!!!!!!! ");

        String applicationCurrentAbsolutePath = Paths.get(".").toAbsolutePath().normalize().toString();
        String simpleRepoPath = applicationCurrentAbsolutePath + File.separator + "logs";
        System.out.println("simpleRepoPath: " + simpleRepoPath);
        BaseRepo repo = new BaseRepo(simpleRepoPath, "mySimpleRepo");
        System.out.println("My simple repo: " + repo.toString());

//        System.out.println(BaseRepo.getFile("00ffd0f362a240188bea5a71d5090070").toString());
    }
}
