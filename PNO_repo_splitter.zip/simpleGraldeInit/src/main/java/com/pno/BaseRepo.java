package com.pno;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.UUID;

public  class BaseRepo {
    private File rootPath;
    private  String repoName;

    public BaseRepo(String repoName, String rootPath) {
        if( repoName == null || repoName.isEmpty()) {
            throw new RuntimeException("Please set  repoName properly.");
        }else{
            this.repoName = repoName;
        }

        File repoRootFolder = new File(rootPath);
        if( repoRootFolder.exists() && repoRootFolder.isDirectory()){
            this.rootPath = repoRootFolder;
        } else{
            throw new RuntimeException("Repo[" + this.repoName + "]: invalid rootPath, initialization fails.");
        }
    }

    @Override
    public String toString() {
        return "BaseRepo{" +
                "rootPath=" + rootPath +
                ", repoName='" + repoName + '\'' +
                '}';
    }

    /**
     *
     * @param UUID - full UUID (the same as in DB)
     * @return
     */
    public  File getFile(String UUID){
        if(UUID == null || UUID.length() != 32) throw new RuntimeException("UUID: '" + UUID + "' can't be null");
        UUID = UUID.replace("-", "");
        if( UUID.length() != 32) throw new RuntimeException("UUID: '" + UUID + "' length is not 32!");
        String path = File.separator + UUID.substring(0, 2)
            + File.separator + UUID.substring(2,4)
            + File.separator + UUID.substring(4,6)
            + File.separator + UUID.substring(6,8)
            + File.separator + UUID;
        return new File(this.rootPath + File.separator + path);
    }

    /**
     *
     * @param UUID
     * @param file
     * @return return relative path of saved file
     */
//    public Path writeFile(String UUID, File file){
//
//    }
//// /content/data/00/ff/d0/f3/00ffd0f362a240188bea5a71d5090070
//    public static Path parseUUIDtoRelativePath(String UUID){ // 1) relative(by concatenate wit Repo.rootPath we can easyly obtain absolute Path of file) or absolute? 2) UUID must looks like uuid.ext ???
//
//    }


    public Path copyFileToExtRepo(File sourceFile, BaseRepo extRepo) throws IOException {
        if(!sourceFile.exists() || !sourceFile.isFile()) throw new RuntimeException("sourceFile " + sourceFile.getAbsolutePath() + " doesn't exist or is not a file.");
        File dstFile = extRepo.getFile(sourceFile.getName());
//        if(dstFile.exists() || dstFile.isFile()) throw new RuntimeException("dstFile " + dstFile.getAbsolutePath() + " already exists. Coping is not allowed. "); // chyba zbędne
        Files.copy(sourceFile.toPath(), dstFile.toPath());
    }

}


